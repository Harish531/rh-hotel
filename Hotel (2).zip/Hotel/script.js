function validateForm() {
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    // Simple validation, you can add more complex validation as needed
    if (username === "" || password === "") {
        alert("Please fill in all fields");
    } else {
        // If validation passes, you can submit the form or perform other actions
        alert("Form submitted successfully!");
        document.getElementById('loginForm').submit(); // Uncomment this line to submit the form
    }
}
function validateRegistrationForm() {
    var regusername = document.getElementById('regusername').value;
    var email = document.getElementById('email').value;
    var regpassword = document.getElementById('regpassword').value;
    var confirmPassword = document.getElementById('confirm-password').value;
    var fullName = document.getElementById('full-name').value;
    var gender = document.getElementById('gender').value;
    var birthdate = document.getElementById('birthdate').value;
    var agreeTerms = document.getElementById('agree-terms').checked;

    // Password validation rules
    var passwordRegex = /^(?=.*[A-Za-z]{8,})(?=.*\d{4,})(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{14,}$/;

    // Simple validation, you can add more complex validation as needed
    if (
        regusername === "" ||
        email === "" ||
        regpassword === "" ||
        confirmPassword === "" ||
        fullName === "" ||
        gender === "" ||
        birthdate === "" ||
        !agreeTerms
    ) {
        alert("Please fill in all fields and agree to the terms and conditions");0
    } else if (regpassword !== confirmPassword) {
        alert("Passwords do not match");
    } else if (!regpassword.match(passwordRegex)) {
        alert("Password should contain at least 8 letters, 4 numbers, 2 symbols, and no spaces");
    } else {
        // If validation passes, you can submit the form or perform other actions
        alert("Form submitted successfully!");
        document.getElementById('registrationForm').submit(); // Uncomment this line to submit the form
    }
}