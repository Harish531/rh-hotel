let cartItems = [];

function addToCart(productId) {
    cartItems.push(productId);
    updateCartDisplay();
}

function updateCartDisplay() {
    const cartList = document.getElementById('cart-items');
    cartList.innerHTML = '';
    const counts = {};
    cartItems.forEach(itemId => {
        counts[itemId] = counts[itemId] ? counts[itemId] + 1 : 1;
    });
    for (const itemId in counts) {
        const li = document.createElement('li');
        li.textContent = `Dish ${itemId} - ${counts[itemId]} items`;
        cartList.appendChild(li);
    }
}

function calculateBill() {
    const pricePerDish = 10; // Assuming each dish costs $10
    let total = 0;
    const counts = {};
    cartItems.forEach(itemId => {
        counts[itemId] = counts[itemId] ? counts[itemId] + 1 : 1;
    });
    for (const itemId in counts) {
        total += counts[itemId] * pricePerDish;
    }
    document.getElementById('total').textContent = `Total: $${total}`;
}
